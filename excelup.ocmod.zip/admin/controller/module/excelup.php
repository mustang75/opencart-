<?php
/*
 * Excelup OpenCart Extension by OpencartBot
 * https://opencartbot.com/en/excelup
 * Released under CC BY-ND 3.0 license
 */
namespace Opencart\Admin\Controller\Extension\Excelup\Module;
class Excelup extends \Opencart\System\Engine\Controller {
	private $error = [];
	private $separator;

	public function __construct($registry) {
		parent::__construct($registry);
		$this->separator = version_compare(VERSION,'4.0.2.0','>=') ? '.' : '|';
	}

	public function save(): void  {
		$this->load->language('extension/excelup/module/excelup');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/excelup/module/excelup')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');
			
			$this->model_setting_setting->editSetting('module_excelup', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function index(): void  {
		$this->load->language('extension/excelup/module/excelup');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/excelup/module/excelup', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/excelup/module/excelup'.$this->separator.'save', 'user_token=' . $this->session->data['user_token'], true);
		$data['action_upload'] = $this->url->link('extension/excelup/module/excelup'.$this->separator.'upload', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=module', true);

		if ($this->config->get('module_excelup_status')) {
			$data['module_excelup_status'] = $this->config->get('module_excelup_status');
		} else {
			$data['module_excelup_status'] = 0;
		}

		if ($this->config->get('module_excelup_firstrow')) {
			$data['module_excelup_firstrow'] = $this->config->get('module_excelup_firstrow');
		} else {
			$data['module_excelup_firstrow'] = 1;
		}

		if ($this->config->get('module_excelup_ident')) {
			$data['module_excelup_ident'] = $this->config->get('module_excelup_ident');
		} else {
			$data['module_excelup_ident'] = 1;
		}

		if ($this->config->get('module_excelup_idcol')) {
			$data['module_excelup_idcol'] = $this->config->get('module_excelup_idcol');
		} else {
			$data['module_excelup_idcol'] = 1;
		}

		if ($this->config->get('module_excelup_price')) {
			$data['module_excelup_price'] = $this->config->get('module_excelup_price');
		} else {
			$data['module_excelup_price'] = 0;
		}

		if ($this->config->get('module_excelup_pricecol')) {
			$data['module_excelup_pricecol'] = $this->config->get('module_excelup_pricecol');
		} else {
			$data['module_excelup_pricecol'] = 2;
		}

		if ($this->config->get('module_excelup_priceup')) {
			$data['module_excelup_priceup'] = $this->config->get('module_excelup_priceup');
		} else {
			$data['module_excelup_priceup'] = 0;
		}

		if ($this->config->get('module_excelup_special')) {
			$data['module_excelup_special'] = $this->config->get('module_excelup_special');
		} else {
			$data['module_excelup_special'] = 0;
		}

		if ($this->config->get('module_excelup_special_new')) {
			$data['module_excelup_special_new'] = $this->config->get('module_excelup_special_new');
		} else {
			$data['module_excelup_special_new'] = 0;
		}

		if ($this->config->get('module_excelup_specialcol')) {
			$data['module_excelup_specialcol'] = $this->config->get('module_excelup_specialcol');
		} else {
			$data['module_excelup_specialcol'] = 2;
		}

		if ($this->config->get('module_excelup_specialup')) {
			$data['module_excelup_specialup'] = $this->config->get('module_excelup_specialup');
		} else {
			$data['module_excelup_specialup'] = 0;
		}

		if ($this->config->get('module_excelup_quantity')) {
			$data['module_excelup_quantity'] = $this->config->get('module_excelup_quantity');
		} else {
			$data['module_excelup_quantity'] = 0;
		}

		if ($this->config->get('module_excelup_quantitycol')) {
			$data['module_excelup_quantitycol'] = $this->config->get('module_excelup_quantitycol');
		} else {
			$data['module_excelup_quantitycol'] = 3;
		}
		
		$data['separator'] = $this->separator;
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/excelup/module/excelup', $data));
	}

	public function upload(): void {
		$this->load->language('extension/excelup/module/excelup');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('extension/excelup/module/excelup');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateUpload()) {

			if ((isset($this->request->files['excelup_upload'] )) && (is_uploaded_file($this->request->files['excelup_upload']['tmp_name']))) {
				$file = DIR_UPLOAD . time() . '.xlsx';
				$moved = move_uploaded_file($this->request->files['excelup_upload']['tmp_name'], $file);

				if ($moved) {
					if ($this->parseFile($file)) {
						$this->session->data['success'] = $this->language->get('text_success_import');
						$this->response->redirect($this->url->link('extension/excelup/module/excelup', 'user_token=' . $this->session->data['user_token'], true));
					} else {
						$this->session->data['warning'] = $this->language->get('error_import');
						$this->response->redirect($this->url->link('extension/excelup/module/excelup', 'user_token=' . $this->session->data['user_token'], true));
					}        
				} else {
				  $this->session->data['warning'] = $this->request->files['excelup_upload']['error'];
				}
			} else {
				$this->session->data['warning'] = $this->language->get('error_upload');
			}
		}
		$this->response->redirect($this->url->link('extension/excelup/module/excelup', 'user_token=' . $this->session->data['user_token'], true));
	}

	protected function parseFile(string $file): string {
		set_time_limit(0);

		if (version_compare(phpversion(), '7.2.', '<')) {
			$this->session->data['warning'] = $this->language->get('error_php_version');
		}

		$this->load->model('extension/excelup/module/excelup');
		
		require (DIR_EXTENSION.'excelup/system/library/excelup/vendor/autoload.php');

		$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();

		$filetype = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file);
		$object = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($filetype);
		$object->setReadDataOnly(true);
		$reader = $object->load($file);

		$sheet = $reader->getActiveSheet();

		$highestRow = $sheet->getHighestRow();
		$highestColumn = $sheet->getHighestColumn();
		$highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);
		if ($this->config->get('module_excelup_firstrow')) {
			$firstrow = intval($this->config->get('module_excelup_firstrow'));
			if (!$firstrow) {
				$firstrow = 1;
			}
		} else {
			$firstrow = 1;
		}

		for ($row = $firstrow; $row <= $highestRow; ++$row) {
			$value = [];

			for ($col = 1; $col <= $highestColumnIndex; ++$col) {
				$value[$col] = $sheet->getCellByColumnAndRow($col, $row)->getValue();
				if (!empty($value[$col]) && substr($value[$col], 0, 1) == '=') {
					$value[$col] = $sheet->getCellByColumnAndRow($col, $row)->getCalculatedValue();
				}
			}

			if (!empty($value[$this->config->get('module_excelup_idcol')])) {

				$ident_val = trim($value[$this->config->get('module_excelup_idcol')]);
	
				if ($this->config->get('module_excelup_price') && $value[$this->config->get('module_excelup_pricecol')] !== false) {
					if (floatval($this->config->get('module_excelup_priceup')) > 0) {
						$percent = floatval($this->config->get('module_excelup_priceup')) / 100;
					} else {
						$percent = 0;
					}
					$price = floatval($value[$this->config->get('module_excelup_pricecol')]) * (1 + $percent);
				} else {
					$price = false;
				}

				if ($this->config->get('module_excelup_special') && !empty($value[$this->config->get('module_excelup_specialcol')])) {
					if (floatval($this->config->get('module_excelup_specialup')) > 0) {
						$percent_special = floatval($this->config->get('module_excelup_specialup')) / 100;
					} else {
						$percent_special = 0;
					}
					$special = floatval($value[$this->config->get('module_excelup_specialcol')]) * (1 + $percent_special);
				} else {
					$special = false;
				}

				if ($this->config->get('module_excelup_quantity')) {
					if(!empty($value[$this->config->get('module_excelup_quantitycol')])) {
						$quantity = intval($value[$this->config->get('module_excelup_quantitycol')]);
					} else {
						$quantity = 0;
					}
				} else {
					$quantity = false;
				}

				$product_id = 0;
				$field = $this->config->get('module_excelup_ident');
				if ($field == 'product_id') {
					$product_id = $ident_val;
				} else {
					$product_id = $this->model_extension_excelup_module_excelup->getProductId($field, $ident_val);
				}

				if (intval($product_id)) {
					$this->model_extension_excelup_module_excelup->updateProduct($product_id, $price, $special, $quantity);
				}
				
			}
		}

		$this->cache->delete('product');

		return true;
	}

	protected function validateUpload(): string {
		$error = '';
		if (!$this->user->hasPermission('modify', 'extension/excelup/module/excelup')) {
			$error = $this->language->get('error_permission');
		}
		return !$error;
	}
	
}